export const VERSION = '5.3.0'; // x-release-please-version
