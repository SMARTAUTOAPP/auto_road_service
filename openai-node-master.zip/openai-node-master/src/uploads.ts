/** @deprecated Import from ./core/uploads instead */
export * from './core/uploads';
