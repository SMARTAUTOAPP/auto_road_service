export type JsonSchema7UnknownType = {};

export function parseUnknownDef(): JsonSchema7UnknownType {
  return {};
}
