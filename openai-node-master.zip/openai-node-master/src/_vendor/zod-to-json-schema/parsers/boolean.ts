export type JsonSchema7BooleanType = {
  type: 'boolean';
};

export function parseBooleanDef(): JsonSchema7BooleanType {
  return {
    type: 'boolean',
  };
}
