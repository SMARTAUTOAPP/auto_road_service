export type JsonSchema7AnyType = {};

export function parseAnyDef(): JsonSchema7AnyType {
  return {};
}
