export type JsonSchema7UndefinedType = {
  not: {};
};

export function parseUndefinedDef(): JsonSchema7UndefinedType {
  return {
    not: {},
  };
}
