# `core`

This directory holds public modules implementing non-resource-specific SDK functionality.
