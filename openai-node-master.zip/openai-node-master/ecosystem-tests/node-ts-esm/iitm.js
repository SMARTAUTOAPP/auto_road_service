import {register} from 'node:module'
register('import-in-the-middle/hook.mjs', import.meta.url)